# Underdogs
This is the first Homework for the group Underdogs. Members: 
- Emma Stenoien
- Thomas Ghebreyesus
- Alex Alessi
- Alexandre Luster

The file "MONET.pdf" contains the biography of Claude Monet. 
The code is contained in "Test3.m" and can be run in Matlab without additional parameters. 
